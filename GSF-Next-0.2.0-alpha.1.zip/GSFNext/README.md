# GSF Next 0.2.0 Alpha

Отдельный экспериментальный Decky-плагин на открытом AFMF-Linux / AMD FidelityFX
Optical Flow. Не использует старый движок Flow Lite и компоненты Lossless Scaling.
Не является DLSS/FSR SDK-интеграцией в игру: доступны только готовые цветовые кадры,
без настоящих motion vectors/depth. Steam Deck OLED ещё не квалифицирован.

1. Установите ZIP через Decky → Developer → Install plugin from ZIP.
2. Уберите прежнюю команду `gsf-test` и другие frame-generation wrappers из запуска игры.
3. Выберите игру в **GSF Next**, нажмите **Подготовить и скопировать запуск**.
4. Вставьте показанную команду в Steam → Свойства игры → Параметры запуска.
   Если Steam запрещает clipboard, выделите команду в поле панели и скопируйте вручную.
5. Начните с ×2, Performance, частоты экрана из Steam, очереди 2 и запаса +3.
   Перезапустите игру после изменения профиля. Встроенную генерацию игры отключите,
   чтобы один владелец управлял промежуточными кадрами.

Для игры 582160 на стандартной установке Deck:

```sh
python3 /home/deck/.local/share/gsf-next/launch.py --appid 582160 -- %command%
```

Сначала подготовьте профиль кнопкой. Выключение в панели оставляет эту команду
безопасным обычным запуском. Плагин не меняет TDP/GPU Clock, системные Vulkan
manifest-файлы и Steam launch options автоматически. Результаты сохраняются в
`~/GSF-Next-Results`; экспорт доступен из панели.

×3/×4 используют один flow на пару и несколько warp-dispatches. Выбор множителя —
верхняя граница: actual WSI ratio зависит от исходного FPS, частоты экрана,
доступных изображений и GPU. Укажите действительную частоту дисплея вручную;
после её изменения обновите профиль и перезапустите игру. Automatic refresh
tracking в этой Alpha отсутствует.

`Generated` — записанные и отправленные GPU-синтезы; `WSI accepted` — принятые
Vulkan-презентации. Ни один из этих счётчиков не доказывает физический scanout.
HDR остаётся обычным выводом; SDR8 — основной путь. 32-bit игры не поддержаны.

Лицензии и полный соответствующий исходный код входят в ZIP. AFMF-Linux by Lain,
MIT, pinned bc56e5bd0e3a6c328aedef664d0d36363fb58b36; FidelityFX shaders retain AMD
MIT notices. Это модифицированная сборка GSF, а не официальный релиз upstream.

Сборка из приложенного SOURCE.tar.gz: `cmake -S engine/gsf-next -B build -G Ninja`,
затем `cmake --build build`. Нужны CMake ≥3.22, Vulkan headers ≥1.3.250, C11,
glslang, SPIR-V Tools, XCB и pthread. В Git checkout
`scripts/build_gsf_next.sh` дополнительно записывает commit в BUILD_INFO.json.
